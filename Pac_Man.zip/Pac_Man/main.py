from Interface_Graphic import *

if __name__ == '__main__':
    interface_graphic = Interface_Graphic()
    interface_graphic.run_game()